import express from "express";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express(), db=new Database("demo.db");
app.use(express.json()); app.use(express.static(path.join(__dirname,"public")));
db.exec(`CREATE TABLE IF NOT EXISTS deposits(id INTEGER PRIMARY KEY, name TEXT, amount REAL, currency TEXT, status TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)`);
app.get("/api/deposits",(req,res)=>res.json(db.prepare("SELECT * FROM deposits ORDER BY id DESC").all()));
app.post("/api/demo-deposit",(req,res)=>{
 const {name,amount,currency}=req.body;
 if(!name || !Number.isFinite(Number(amount)) || Number(amount)<=0 || !["INR","USDT"].includes(currency)) return res.status(400).json({error:"Valid demo details required"});
 const result=db.prepare("INSERT INTO deposits(name,amount,currency,status) VALUES(?,?,?,'SIMULATED')").run(name,Number(amount),currency);
 res.json({id:result.lastInsertRowid,status:"SIMULATED",message:"Demo entry saved; no money was collected."});
});
app.listen(process.env.PORT||3000,()=>console.log("Demo running on http://localhost:3000"));